.onAttach <- function (lib, pkg) {
  packageStartupMessage("This is RandomFieldsUtils Version: 0.2.1");
}
