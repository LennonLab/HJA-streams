/* initNerrorSpherModels.h */
#ifndef initNerrorSPHERMODELS_H
#define initNerrorSPHERMODELS_H 1


/* declaration of functions */
void initSpherModels( );

#endif /* initNerrorSpherModels.h */
