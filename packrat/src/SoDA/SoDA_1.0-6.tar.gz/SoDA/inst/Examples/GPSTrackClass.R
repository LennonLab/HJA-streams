setClass("GPSTrack",
  representation(latitude = "numeric", longtitude = "numeric",
                 elevation = "numeric", time = "DateTime")
)
