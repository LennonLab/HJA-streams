x <- seq(from=1.1, to=1.7, by=.1)
x[2] <- "XXX"
x
