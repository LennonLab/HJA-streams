con = url("http://www-stat.stanford.edu/~jmc4/SoDA/inst/Examples/weather1.csv")
w1 = read.csv(con)
close(con)
