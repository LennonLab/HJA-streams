x <- seq(from=1.1, to=1.7, by=.1)
length(x)
x[c(1,9)]
x[c(1,9)] <- -1
x
