require(SoDA, quietly = TRUE)
binaryRep(c(-.45, .15))
