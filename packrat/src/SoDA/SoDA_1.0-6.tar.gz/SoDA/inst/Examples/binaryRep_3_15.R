require(SoDA, quietly = TRUE)
binaryRep(c(3 * .15))
