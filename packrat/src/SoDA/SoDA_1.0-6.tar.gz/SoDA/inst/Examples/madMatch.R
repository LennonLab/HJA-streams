match.call(mad,
      quote(mad(xx[,j], constant = curConst, na.rm = TRUE)))
